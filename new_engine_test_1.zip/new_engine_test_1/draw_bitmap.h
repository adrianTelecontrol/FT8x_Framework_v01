#ifndef _DRAW_BITMAP_H_
#define _DRAW_BITMAP_H_


void TEST_collideSquares(void);

#endif