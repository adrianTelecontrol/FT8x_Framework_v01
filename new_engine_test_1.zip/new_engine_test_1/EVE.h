/*
 * EVE.h
 *
 *  Created on: 12/01/2026
 *  Author: Adrian Pulido
 */
#ifndef EVE_ENGINE_H
#define EVE_ENGINE_H

#include "FT8xx.h"
#include <stdint.h>

#define DL_BUFFER_SIZE 4096

extern uint16_t dlBufferIndex;
extern uint8_t dlBuffer[DL_BUFFER_SIZE];

typedef enum {
    EVE_STATE_IDLE   = 0, 
    EVE_STATE_BUSY   = 1, 
    EVE_STATE_FAULT  = 2, 
    EVE_STATE_RESET  = 3,
    EVE_STATE_SPI_ERR = 4 // New: Indicates physical wire failure
} EVE_State_t;

EVE_State_t EVE_GetState(void);
void EVE_Util_DebugReport(void);
void EVE_ClearFault(void);

//*****************************************************************************
//
//                          EVE DRIVER
//
//*****************************************************************************
void EVE_Write32(uint32_t ftData32);
void EVE_Write16(uint16_t ftData16);
void EVE_Write8(uint8_t ftData8);
uint32_t EVE_Read32(void);
uint16_t EVE_Read16(void);
uint8_t EVE_Read8(void);
void EVE_Flush_Buffer(void);

void EVE_AddrForWr(uint32_t ftAddress);
void EVE_AddrForRd(uint32_t ftAddress);
void EVE_MemWrite32(uint32_t ftAddress, uint32_t ftData32);
void EVE_MemWrite16(uint32_t ftAddress, uint16_t ftData16);
void EVE_MemWrite8(uint32_t ftAddress, uint8_t ftData8);
uint32_t EVE_MemRead32(uint32_t ftAddress);
uint16_t EVE_MemRead16(uint32_t ftAddress);
uint8_t EVE_MemRead8(uint32_t ftAddress); // AVS Orig uint8_t
void EVE_CmdWrite(uint8_t EVECmd, uint8_t Param);
uint16_t EVE_IncCMDOffset(uint16_t currentOffset, uint16_t commandSize);
uint8_t EVE_WaitCmdFifoEmpty(void);
uint32_t EVE_GetCurrentWritePointer(void);
uint16_t EVE_CheckFreeSpace(uint16_t CmdOffset);
uint32_t EVE_ReadCalibrateReg32(uint8_t i);
void EVE_WriteAllCalibrate32(uint32_t data[6]);

//*****************************************************************************
//
//                          EVE API
//
//*****************************************************************************
void API_Init(void);
void API_WakeUpScreen(void);
void API_LIB_BeginCoProList(void);
void API_LIB_EndCoProList(void);
void API_LIB_AwaitCoProEmpty(void);
void API_LIB_WriteDataRAMG(const uint8_t *ImgData, uint32_t DataSize,
                           uint32_t DestAddress);
bool EVE_VerifyRAMG(const uint8_t *ImgData, uint32_t DataSize, uint32_t DestAddress);
void API_LIB_WriteDataRAMG_uDMA(const uint8_t *pui8ImgSrc, const uint32_t ui32Size, uint32_t ui32DestAddr);
uint8_t API_SendString(const char *string);
void API_LIB_WriteDataToCMD(const uint8_t *ImgData, uint32_t TotalDataSize);
// Graphics instructions
void API_CLEAR_COLOR_RGB(uint8_t R, uint8_t G, uint8_t B);
void API_CLEAR(uint8_t C, uint8_t S, uint8_t T);
void API_COLOR_RGB(uint8_t R, uint8_t G, uint8_t B);
void API_VERTEX2F(int16_t x, int16_t y);
void API_VERTEX2II(uint16_t x, uint16_t y, uint8_t handle, uint8_t cell);
void API_BITMAP_HANDLE(uint8_t handle);
void API_BITMAP_SOURCE(uint32_t addr);
void API_BITMAP_LAYOUT(uint8_t format, uint16_t linestride, uint16_t height);
void API_BITMAP_SIZE(uint8_t filter, uint8_t wrapx, uint8_t wrapy,
                     uint16_t width, uint16_t height);
void API_CELL(uint8_t cell);
void API_TAG(uint8_t s);
void API_ALPHA_FUNC(uint8_t func, uint8_t ref);
void API_STENCIL_FUNC(uint8_t func, uint8_t ref, uint8_t mask);
void API_BLEND_FUNC(uint8_t src, uint8_t dst);
void API_STENCIL_OP(uint8_t sfail, uint8_t spass);
void API_POINT_SIZE(uint16_t size);
void API_LINE_WIDTH(uint16_t width);
void API_CLEAR_COLOR_A(uint8_t alpha);
void API_COLOR_A(uint8_t alpha);
void API_CLEAR_STENCIL(uint8_t s);
void API_CLEAR_TAG(uint8_t s);
void API_STENCIL_MASK(uint8_t mask);
void API_TAG_MASK(uint8_t mask);
void API_SCISSOR_XY(uint16_t x, uint16_t y);
void API_SCISSOR_SIZE(uint16_t width, uint16_t height);
void API_CALL(uint16_t dest);
void API_JUMP(uint16_t dest);
void API_BEGIN(uint8_t prim);
void API_COLOR_MASK(uint8_t r, uint8_t g, uint8_t b, uint8_t a);
void API_END(void);
void API_SAVE_CONTEXT(void);
void API_RESTORE_CONTEXT(void);
void API_RETURN(void);
void API_MACRO(uint8_t m);
void API_DISPLAY(void);
// Co-Processor Widgets
void API_CMD_TEXT(int16_t x, int16_t y, int16_t font, uint16_t options,
                  const char *string);
void API_CMD_BUTTON(int16_t x, int16_t y, int16_t w, int16_t h, int16_t font,
                    uint16_t options, const char *string);
void API_CMD_KEYS(int16_t x, int16_t y, int16_t w, int16_t h, int16_t font,
                  uint16_t options, const char *string);
void API_CMD_NUMBER(int16_t x, int16_t y, int16_t font, uint16_t options,
                    int32_t n);
void API_CMD_LOADIDENTITY(void);
void API_CMD_TOGGLE(int16_t x, int16_t y, int16_t w, int16_t font,
                    uint16_t options, uint16_t state, const char *string);
void API_CMD_GAUGE(int16_t x, int16_t y, int16_t r, uint16_t options,
                   uint16_t major, uint16_t minor, uint16_t val,
                   uint16_t range);
void API_CMD_REGREAD(uint32_t ptr, uint32_t result);
void API_CMD_GETPROPS(uint32_t ptr, uint32_t w, uint32_t h);
void API_CMD_MEMCPY(uint32_t dest, uint32_t src, uint32_t num);
void API_CMD_SPINNER(int16_t x, int16_t y, uint16_t style, uint16_t scale);
void API_CMD_BGCOLOR(uint32_t c);
void API_CMD_SWAP(void);
void API_CMD_INFLATE(uint32_t ptr);
void API_CMD_TRANSLATE(int32_t tx, int32_t ty);
void API_CMD_STOP(void);
void API_CMD_SLIDER(int16_t x, int16_t y, int16_t w, int16_t h,
                    uint16_t options, uint16_t val, uint16_t range);
void API_BITMAP_TRANSFORM_A(long a);
void API_BITMAP_TRANSFORM_B(long b);
void API_BITMAP_TRANSFORM_C(long c);
void API_BITMAP_TRANSFORM_D(long d);
void API_BITMAP_TRANSFORM_E(long e);
void API_BITMAP_TRANSFORM_F(long f);
void API_CMD_INTERRUPT(uint32_t ms);
void API_CMD_FGCOLOR(uint32_t c);
void API_CMD_ROTATE(int32_t a);
void API_CMD_MEMWRITE(uint32_t ptr, uint32_t num);
void API_CMD_SCROLLBAR(int16_t x, int16_t y, int16_t w, int16_t h,
                       uint16_t options, uint16_t val, uint16_t size,
                       uint16_t range);
void API_CMD_GETMATRIX(int32_t a, int32_t b, int32_t c, int32_t d, int32_t e,
                       int32_t f);
void API_CMD_SKETCH(int16_t x, int16_t y, uint16_t w, uint16_t h, uint32_t ptr,
                    uint16_t format);
void API_CMD_MEMSET(uint32_t ptr, uint32_t value, uint32_t num);
void API_CMD_GRADCOLOR(uint32_t c);
void API_CMD_BITMAP_TRANSFORM(int32_t x0, int32_t y0, int32_t x1, int32_t y1,
                              int32_t x2, int32_t y2, int32_t tx0, int32_t ty0,
                              int32_t tx1, int32_t ty1, int32_t tx2,
                              int32_t ty2, uint16_t result);
void API_CMD_CALIBRATE(uint32_t result);
void API_CMD_SETFONT(uint32_t font, uint32_t ptr);
void API_CMD_LOGO(void);
void API_CMD_APPEND(uint32_t ptr, uint32_t num);
void API_CMD_MEMZERO(uint32_t ptr, uint32_t num);
void API_CMD_SCALE(int32_t sx, int32_t sy);
void API_CMD_CLOCK(int16_t x, int16_t y, int16_t r, uint16_t options,
                   uint16_t h, uint16_t m, uint16_t s, uint16_t ms);
void API_CMD_GRADIENT(int16_t x0, int16_t y0, uint32_t rgb0, int16_t x1,
                      int16_t y1, uint32_t rgb1);
void API_CMD_SETMATRIX(void);
void API_CMD_TRACK(int16_t x, int16_t y, int16_t w, int16_t h, int16_t tag);
void API_CMD_GETPTR(uint32_t result);
void API_CMD_PROGRESS(int16_t x, int16_t y, int16_t w, int16_t h,
                      uint16_t options, uint16_t val, uint16_t range);
void API_CMD_COLDSTART(void);
void API_CMD_DIAL(int16_t x, int16_t y, int16_t r, uint16_t options,
                  uint16_t val);
void API_CMD_LOADIMAGE(uint32_t ptr, uint32_t options);
void API_CMD_DLSTART(void);
void API_CMD_SNAPSHOT(uint32_t ptr);
void API_CMD_SCREENSAVER(void);
void API_CMD_MEMCRC(uint32_t ptr, uint32_t num, uint32_t result);

#ifdef FT_81X_ENABLE
// GPU
void API_VERTEX_FORMAT(uint8_t frac);
void API_BITMAP_LAYOUT_H(uint8_t linestride, uint8_t height);
void API_BITMAP_SIZE_H(uint8_t width, uint8_t height);
void API_PALETTE_SOURCE(uint32_t addr);
void API_VERTEX_TRANSLATE_X(uint32_t x);
void API_VERTEX_TRANSLATE_Y(uint32_t y);
void API_NOP(void);
// CO-PRO
void API_CMD_VIDEOSTART(void);
void API_CMD_SETROTATE(uint32_t r);
void API_CMD_SETFONT2(uint32_t font, uint32_t ptr, uint32_t firstchar);
void API_CMD_MEDIAFIFO(uint32_t ptr, uint32_t size);
void API_CMD_SNAPSHOT2(uint32_t fmt, uint32_t ptr, int16_t x, int16_t y,
                       int16_t w, int16_t h);
void API_CMD_INT_SWLOADIMAGE(uint32_t ptr, uint32_t options);
void API_CMD_CSKETCH(int16_t x, int16_t y, uint16_t w, uint16_t h, uint32_t ptr,
                     uint16_t format, uint16_t freq);
void API_CMD_ROMFONT(uint32_t font, uint32_t romslot);
void API_CMD_PLAYVIDEO(uint32_t options);
void API_CMD_SYNC(void);
void API_CMD_VIDEOFRAME(uint32_t dst, uint32_t ptr);
void API_CMD_SETBASE(uint32_t base);
void API_CMD_SETBITMAP(uint32_t source, uint16_t fmt, uint16_t w, uint16_t h);
void API_CMD_SETSCRATCH(uint32_t handle);
#endif

#endif // EVE_ENGINE_H
