
#include <xdc/runtime/System.h>
#include "gfx.h"
#include "config_screen_FT8xx.h"
#include "form_common.h"
#include "EVE_colors.h"
#include "home_form.h"

static Rectangle g_sPanelRect;
static Button g_sPushButton;
static RegionTouchObject g_sLockWidgetRegTouch;

void pushButtonOnClicked(Button *btn)
{
    if(btn->status == BTN_STATE_PRESSED)
        btn->status = BTN_STATE_NORMAL;
    else
    {
        btn->status = BTN_STATE_PRESSED;
        btn->pos.x = LCD_WIDTH / 2 - btn->dim.width / 2;
        btn->pos.y = LCD_HEIGHT / 2 - btn->dim.height / 2;
        gfx_initRegTouch((void *)btn, WD_TYPE_BUTTON);
    }

    System_printf("Button clicked!");
    System_flush();
}

void pushButtonOnRelease(Button *btn)
{

}

void pushButtonOnPosChanged(Button *btn, Position newPos)
{
    if(newPos.x >= 0 && newPos.x < LCD_WIDTH - btn->dim.width && newPos.y >= 0 &&newPos.y < LCD_HEIGHT - btn->dim.height)
    {
        btn->pos.x = newPos.x;
        btn->pos.y = newPos.y;
        gfx_initRegTouch((void *)btn, WD_TYPE_BUTTON);
    }
    System_printf("Button pos: (%d, %d)", btn->pos.x, btn->pos.y);
    System_flush();
}

void initHomeForm(void)
{
    g_sPanelRect.pos.x = HORIZONTAL_MARGIN;
    g_sPanelRect.pos.y = VERTICAL_MARGIN;
    g_sPanelRect.dim.width = LCD_WIDTH - 2 * HORIZONTAL_MARGIN;
    g_sPanelRect.dim.height = LCD_HEIGHT - 2 * VERTICAL_MARGIN;
    g_sPanelRect.round = 0;
    g_sPanelRect.color = EVE_BLUE;

    g_sPushButton.dim.width = BUTTON_WIDTH;
    g_sPushButton.dim.height = BUTTON_HEIGHT;
    g_sPushButton.pos.x = LCD_WIDTH / 2 - g_sPushButton.dim.width / 2;
    g_sPushButton.pos.y = LCD_HEIGHT / 2 - g_sPushButton.dim.height / 2;
    g_sPushButton.label = "PUSH ME";
    g_sPushButton.sizeFont = 28;
    gfx_initRegTouch((void *)&g_sPushButton, WD_TYPE_BUTTON);
    g_sPushButton.color.foreground = EVE_GREEN;
    g_sPushButton.color.text = EVE_WHITE;

    g_sPushButton.onClicked = pushButtonOnClicked;
    g_sPushButton.onRelease = pushButtonOnRelease;
    g_sPushButton.onPosChanged = pushButtonOnPosChanged;
}

void showHomeForm(void)
{
    gfx_start(EVE_BLACK);
    gfx_Rectangle(&g_sPanelRect);
    gfx_Button(&g_sPushButton);
    gfx_end();
}

bool wasHomeFormTouched(TouchStatus touchStatus, gesture_type_e gesture)
{
    Position newPos;
    switch (gesture) 
    {
        case GESTURE_LOCK_OBJ:
            System_printf("Gesture: Locking object");
            if( gfx_touchObject(g_sPushButton.regTouch, touchStatus) )
                g_sLockWidgetRegTouch = g_sPushButton.regTouch;
            break;
        case GESTURE_DRAG:
            System_printf("Gesture: Dragging object");
            if(gfx_touchObject(g_sLockWidgetRegTouch, touchStatus))
            {
                newPos.x = touchStatus.x - g_sPushButton.dim.width / 2;
                newPos.y = touchStatus.y - g_sPushButton.dim.height / 2;
                g_sPushButton.onPosChanged(&g_sPushButton, newPos);
                g_sLockWidgetRegTouch = g_sPushButton.regTouch;
            }
            break;
        case GESTURE_CLICK:
            System_printf("Gesture: Clicking object");
            g_sPushButton.onClicked(&g_sPushButton);
            break;
        default:
            break;
    }
    System_flush();
}
