#ifndef FORMS_COMMON_H_
#define FORMS_COMMON_H_

#define BUTTON_WIDTH        200
#define BUTTON_HEIGHT       120
#define HORIZONTAL_MARGIN   20
#define VERTICAL_MARGIN     20 

#endif // FORMS_COMMON_H


