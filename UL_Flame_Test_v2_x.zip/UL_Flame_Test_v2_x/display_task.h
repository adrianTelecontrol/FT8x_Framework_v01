#ifndef DISPLAY_TASK_H
#define DISPLAY_TASK_H

#include <xdc/std.h>

void displayTaskStart(void);
// Void displayTask(UArg arg0, UArg arg1);

#endif

